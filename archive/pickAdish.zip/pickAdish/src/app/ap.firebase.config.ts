
export const FIREBASE_CONFIG= {
    apiKey: "AIzaSyASKRKyNwRsaj9FfQCzkAhUCjDVmKhzNgA",
    authDomain: "pick-a-dish.firebaseapp.com",
    databaseURL: "https://pick-a-dish.firebaseio.com",
    projectId: "pick-a-dish",
    storageBucket: "pick-a-dish.appspot.com",
    messagingSenderId: "362598252651"}
 ;
