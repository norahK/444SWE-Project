export interface Tip{
  image:string;
  title:string;
  body:string;
 user_id:string;
  date:string;//Date
}
