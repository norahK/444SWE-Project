export interface User{
  email:string;
  password:string;
  name:string;
  id:string;
  profileImage:string;
  bio:string;

  lists:Array<any>;



}
