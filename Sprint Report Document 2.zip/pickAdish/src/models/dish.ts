export interface Dish{
  name:string;
  price:number;
  shop:string;
  id:string;
number_of_raters :number;
average_rate:number;
}
